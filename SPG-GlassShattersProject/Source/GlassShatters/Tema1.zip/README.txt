Dragan Anca Mihaela
Tema 1 - SPG - Glass Shatters

Buttons :	* 1 - activare mode sticla
		* 2 - activare mode wireframe
		* 3 - activare mode normale
		* 0 - start animation
		* 9 - restart
		* up - crestere speed
		* down - incetinire speed